#include "ex1.h"
#include <iostream>




//=============================================
int main(int argc, char** argv){
	int size = atoi(argv[1]);
	int lign = atoi(argv[2]);
	void *m = aligned_malloc(size, lign);
	std::cout << "size =  " << size << '\n'
		  << "lign = " << lign << '\n'
		  << "address = " << m << '\n';
      	return 1;	
}

//   $g++ -o ex ex1.cpp
//   $./ex 16 64
