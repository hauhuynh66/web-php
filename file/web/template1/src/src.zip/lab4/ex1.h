#include <stdlib.h>
void *aligned_free(void *ptr) {
	free(((void **)ptr)[-1]);
}

void *aligned_malloc(size_t s, size_t al){
	int of = al - 1 + sizeof(void*);
	void *ptr1;
	void **ptr2;
	if ((ptr1 = (void*)malloc(s + of)) == NULL) return NULL;
	ptr2 = (void**)(((size_t)(ptr1)+of) & ~(al - 1));
	ptr2[-1] = ptr1;
       	return ptr2;	
}
